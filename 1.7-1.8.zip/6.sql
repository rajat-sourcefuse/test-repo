
UPDATE organization_employee SET first_name = 'John',last_name = 'Aperio',npi = NULL,title = NULL,custom_property = NULL,checksum = NULL WHERE id = 'organizationEmployee:001';
DELETE FROM organization_employee WHERE id = 'organizationEmployee:002';
