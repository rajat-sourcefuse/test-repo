
UPDATE meta_oml_script SET authorization_policy = 'metaAuthPolicy:denyInstructorPatient' WHERE id = 'metaOmlScript:068';
UPDATE meta_oml_script SET name = 'SyncEncounterInfoCron' WHERE id = 'metaOmlScript:069';