
UPDATE synap_user SET first_name = 'John',last_name = 'Aperio',failure_attempts = NULL,custom_property = NULL,checksum = NULL WHERE id = 'synapUser:001';
