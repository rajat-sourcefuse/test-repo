
ALTER TABLE patient_employment_info ADD CONSTRAINT fk_dcc5f569dbb1345daf5c65041d015fb3 foreign  KEY (ncm_sync_status) REFERENCES meta_sync_status(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE patient_medication ADD CONSTRAINT fk_c84a7113f9ef352823d96f0dffacf032 foreign  KEY (meta_route) REFERENCES meta_medication_delivery_route(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE calendar_item ADD CONSTRAINT fk_ede1cceab2f10b684b3e7215f85c9e9d foreign  KEY (secondary_instructor_user) REFERENCES organization_employee(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE calendar_item ADD CONSTRAINT fk_2e2ac46d7871ee0f1d1d129f6e0f0aaf foreign  KEY (instructor_user) REFERENCES organization_employee(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE patient_diagnosis_program ADD CONSTRAINT fk_8e702dbf8afc880e50a2a34ac9cbc8a0 foreign  KEY (patient_diagnosis_id) REFERENCES patient_diagnosis(id) DEFERRABLE INITIALLY IMMEDIATE;