
SET CONSTRAINTS ALL DEFERRED;
ALTER TABLE patient_medication DROP CONSTRAINT fk_9be26c44fa82d6a242913dd511d6ee3f;
ALTER TABLE patient ADD COLUMN is_image_upload boolean NULL DEFAULT false;
ALTER TABLE patient_employment_info ADD COLUMN ncm_sync_status character varying(255) NULL DEFAULT 'metaSyncStatus:pending';
ALTER TABLE calendar_item ADD COLUMN instructor_user character varying(255) NULL;
ALTER TABLE calendar_item ADD COLUMN secondary_instructor_user character varying(255) NULL;
ALTER TABLE calendar_item ADD COLUMN registrant_by_registrant_limit character varying(128) NULL;
ALTER TABLE calendar_item ADD COLUMN location character varying(128) NULL;
ALTER TABLE calendar_item ADD COLUMN program_name character varying(128) NULL;
ALTER TABLE calendar_item ADD COLUMN primary_provider character varying(128) NULL;
ALTER TABLE course ALTER COLUMN registrant_limit TYPE numeric;
ALTER TABLE patient_diagnosis ALTER COLUMN icd10_desc TYPE text;
ALTER TABLE patient_diagnosis ALTER COLUMN snomed_desc TYPE text;