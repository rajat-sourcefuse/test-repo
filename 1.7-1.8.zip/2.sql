
UPDATE oml_object SET is_external_syncable = true WHERE name = 'patientEmploymentInfo';
UPDATE oml_object SET authorization_policy = 'metaAuthPolicy:denyPatient' WHERE name = 'calendarItem';