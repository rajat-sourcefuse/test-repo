
UPDATE meta_social_needs SET key = 'relatedToTransition' WHERE id = 'metaSocialNeeds:059';