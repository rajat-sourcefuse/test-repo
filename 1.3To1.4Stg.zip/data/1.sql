
SET CONSTRAINTS ALL DEFERRED;
CREATE TABLE meta_synap_profile (profile character varying(128) NULL, permission character varying(255) NULL, created_on_date date NULL, created_on_time character varying(128) NULL, created_by character varying(255) NULL, id character varying(128) NOT NULL, tags varchar[] NULL, organization_id character varying(255) NULL, custom_property text NULL, checksum character varying(128) NULL, object_path ltree NULL, is_deleted boolean NULL DEFAULT false);
CREATE TABLE meta_auth_policy (policy text NULL DEFAULT '{}', created_on_date date NULL, created_on_time character varying(128) NULL, created_by character varying(255) NULL, id character varying(128) NOT NULL, tags varchar[] NULL, organization_id character varying(255) NULL, custom_property text NULL, checksum character varying(128) NULL, object_path ltree NULL, is_deleted boolean NULL DEFAULT false);
ALTER TABLE patient ADD COLUMN user_type character varying(255) NULL;
ALTER TABLE meta_user_type ADD COLUMN is_internal boolean NULL DEFAULT false;
ALTER TABLE meta_user_type ADD COLUMN object_type character varying(128) NULL;
CREATE INDEX meta_synap_profile_tags ON meta_synap_profile USING gin(tags);
CREATE INDEX meta_auth_policy_tags ON meta_auth_policy USING gin(tags);