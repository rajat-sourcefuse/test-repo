
UPDATE meta_user_type SET is_internal = false,object_type = 'organizationEmployee' WHERE id = 'metaUserType:user';
UPDATE meta_user_type SET is_internal = false,object_type = 'organizationEmployee' WHERE id = 'metaUserType:admin';
UPDATE meta_user_type SET is_internal = true,object_type = 'organizationEmployee' WHERE id = 'metaUserType:system';
INSERT INTO meta_user_type(value,value_order,is_internal,object_type,created_on_date,created_on_time,created_by,id,tags,organization_id,custom_property,checksum,object_path,is_deleted) values ('Instructor','4',false,'organizationEmployee',NULL,NULL,NULL,'metaUserType:instructor',NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO meta_user_type(value,value_order,is_internal,object_type,created_on_date,created_on_time,created_by,id,tags,organization_id,custom_property,checksum,object_path,is_deleted) values ('Client','5',true,'patient',NULL,NULL,NULL,'metaUserType:client',NULL,NULL,NULL,NULL,NULL,false);