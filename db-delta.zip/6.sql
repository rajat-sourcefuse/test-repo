UPDATE kch_program SET short_name = 'WWE' WHERE id = 'kchProgram:003';

