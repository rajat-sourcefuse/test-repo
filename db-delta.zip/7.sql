
ALTER TABLE meta_social_needs_category ADD CONSTRAINT unik_meta_social_needs_category_id unique (id);
ALTER TABLE meta_social_needs ADD CONSTRAINT unik_meta_social_needs_id unique (id);
ALTER TABLE patient_social_needs ADD CONSTRAINT unik_patient_social_needs_id unique (id);
ALTER TABLE meta_social_needs_category ADD CONSTRAINT pk_meta_social_needs_category_id primary  KEY (id);
ALTER TABLE meta_social_needs ADD CONSTRAINT pk_meta_social_needs_id primary  KEY (id);
ALTER TABLE patient_social_needs ADD CONSTRAINT pk_patient_social_needs_id primary  KEY (id);
ALTER TABLE course_session ADD CONSTRAINT fk_c68cc1a706d9c73af8afcb9ac24f2b61 foreign  KEY (secondary_instructor_user) REFERENCES organization_employee(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE meta_social_needs_category ADD CONSTRAINT fk_c9896fd0c8327a3ff9c397d2c6a8a4de foreign  KEY (organization_id) REFERENCES organization(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE meta_social_needs_category ADD CONSTRAINT fk_d75a6e4c4179ba9841169fea93d73bfc foreign  KEY (created_by) REFERENCES synap_user(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE meta_social_needs ADD CONSTRAINT fk_015fa9de20ccf4c8c12dfb0681559077 foreign  KEY (organization_id) REFERENCES organization(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE meta_social_needs ADD CONSTRAINT fk_f40eeadb24e96cd9f5fbc1452edd7918 foreign  KEY (meta_social_needs_category_id) REFERENCES meta_social_needs_category(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE meta_social_needs ADD CONSTRAINT fk_0e21cbf20d846dd28048d0a3c3128f10 foreign  KEY (created_by) REFERENCES synap_user(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE meta_social_needs ADD CONSTRAINT fk_e3f71b9e54b1d65da16baa3dca3cf817 foreign  KEY (category_id) REFERENCES meta_social_needs_category(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE patient_social_needs ADD CONSTRAINT fk_ef23f0c5b67156ede354757c011a1c00 foreign  KEY (organization_id) REFERENCES organization(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE patient_social_needs ADD CONSTRAINT fk_aac887795514783c1538c8a5b9a796bb foreign  KEY (patient_id) REFERENCES patient(id) DEFERRABLE INITIALLY IMMEDIATE;
ALTER TABLE patient_social_needs ADD CONSTRAINT fk_5062931bffe66957dd4daaea1be53555 foreign  KEY (created_by) REFERENCES synap_user(id) DEFERRABLE INITIALLY IMMEDIATE;
SET CONSTRAINTS ALL IMMEDIATE;
