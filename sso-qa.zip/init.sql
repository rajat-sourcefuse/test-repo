--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1 (Ubuntu 11.1-1.pgdg18.04+1)
-- Dumped by pg_dump version 11.1 (Ubuntu 11.1-1.pgdg18.04+1)

-- Started on 2019-02-16 18:52:06 IST

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 198 (class 1259 OID 251714)
-- Name: user_password_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_password_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


-- ALTER TABLE public.user_password_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 197 (class 1259 OID 251706)
-- Name: user_password; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_password (
    password character varying(128),
    username character varying(128),
    created_on timestamp with time zone DEFAULT now(),
    id bigint DEFAULT nextval('public.user_password_id_seq'::regclass) NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


-- ALTER TABLE public.user_password OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 237024)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    username character varying(255),
    password character varying(100) NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_locked boolean DEFAULT false NOT NULL,
    resend_email boolean DEFAULT false NOT NULL,
    failure_attempts integer,
    password_set_time character varying(128)
);


-- ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 2814 (class 2606 OID 251710)
-- Name: user_password user_password_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_password
    ADD CONSTRAINT user_password_pkey PRIMARY KEY (id);


--
-- TOC entry 2810 (class 2606 OID 237041)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);

INSERT INTO public.users(
	username, password, is_active, is_locked, resend_email, failure_attempts, password_set_time)
	VALUES ('admin@aperiohealth.com', '$2a$10$BOE7ekwzBR6A5pdrlqOKEexuD4mey/Ka.jhmYyJ1lyC.yllJIwq2O', true, false, false, 0, null),('cron@aperiohealth.com', '$2a$10$BOE7ekwzBR6A5pdrlqOKEexuD4mey/Ka.jhmYyJ1lyC.yllJIwq2O', true, false, false, 0, null),('integration@aperiohealth.com', '$2a$10$BOE7ekwzBR6A5pdrlqOKEexuD4mey/Ka.jhmYyJ1lyC.yllJIwq2O', true, false, false, 0, null);
-- Completed on 2019-02-16 18:52:06 IST

--
-- PostgreSQL database dump complete
--

