const winston = require('winston')
const config = require('./')
const bcrypt = require('bcrypt')

module.exports = {

    register: async (req, res) => {
        const input = req.body;
        if (!ValidateEmail(input.username)) {
            throw new Error("Invalid username format must be email.");
        }
        if (!input.hasOwnProperty('password')) {
            throw new Error("Password is mandatory.");
        }
        await validatePasswordStrength(input.password)


        input.password = await passwordEncrypt(input.password)
        var d = new Date();

        input.password_set_time = d.getTime();
        let keys = Object.keys(input);
        let params = [input].map(obj => keys.map(key => obj[key]));

        let query = 'INSERT INTO users (' + keys.join(',') + ') VALUES (\'' + params[0].join("\',\'") + '\')';
        let result = runQuery(req.db, query, []);

        res.json(result)

    },
    changePassword: async (req, res, next) => {
        try {
            const input = req.body;
            let query = 'SELECT username, password,is_active,is_locked,failure_attempts FROM users WHERE username=$1'
            let params = [input.username];
            let result = await runQuery(req.db, query, params);
            //console.log(result)

            if (result.rows.length > 0) {
                let passComp = await comparePassword(input.password, result.rows[0].password)
                if (!passComp) {
                    throw new Error("Your existing password is incorrect.");
                }

                await validatePasswordStrength(input.newPassword)
                let resp = await updatePasswordQuery(req.db, input.username, input.newPassword)
                let response = false;
                if (resp) {
                    response = [{
                        'status': true,
                        'message': "Password has been updated successfully."
                    }]
                }
                res.json(response);
            } else {
                throw new Error("username not correct.");
            }
        } catch (e) {

            return next(e);

        }

    },
    resetPassword: async (req, res, next) => {
        try {

            const input = req.body;
            let query = 'SELECT username, password,is_active,is_locked,failure_attempts FROM users WHERE username=$1'
            let params = [input.username];
            let result = await runQuery(req.db, query, params);


            if (result.rows.length > 0) {

                await validatePasswordStrength(input.password)

                let resp = await updatePasswordQuery(req.db, input.username, input.password)
                let response = false;
                if (resp) {
                    response = [{
                        'status': true,
                        'message': "Password has been updated successfully."
                    }]
                    res.json(response);
                }
            } else {
                throw new Error("username not correct.");
            }
        } catch (e) {

            return next(e);
        }

    },
    userExists: async (req, res, next) => {
        try {
            const input = req.body;
            //also set max attempts to 0
            console.log(input)
            let query = 'SELECT * FROM users WHERE username=$1'
            let params = [input.username];

            let result = await runQuery(req.db, query, params);
            let response={};

            if (result.rows.length > 0) {
                response = {
                    'status': true,
                    'message': "user Exists."
                }
            }else{
                response = {
                    'status': false,
                    'message': "user does not Exist."
                }
            }
            res.json(response)
        } catch (e) {

            return next(e);
        }

    },
    unlockAccount: (req, res, next) => {
        const input = req.body;
        //also set max attempts to 0
        console.log(input)
        let query = 'UPDATE users SET is_locked=false,failure_attempts=0 WHERE username=$1'
        let params = [input.username];
        runQuery(req.db, query, params);
        res.json(input)

    },
    lockAccount: (req, res, next) => {
        const input = req.body;
        let query = 'UPDATE users SET is_locked=true WHERE username=$1'
        let params = [input.username];
        runQuery(req.db, query, params);
        console.log(input)

        res.json(input)

    },

    activateAccount: (req, res, next) => {
        const input = req.body;
        let query = 'UPDATE users SET is_active=true WHERE username=$1'
        let params = [input.username];
        runQuery(req.db, query, params);
        console.log(input)

        res.json(input)

    },
    deactivateAccount: async (req, res, next) => {
        const input = req.body;
        let query = 'UPDATE users SET is_active=false WHERE username=$1'
        let params = [input.username];
        runQuery(req.db, query, params);
        console.log(input)

        res.json(input)

    },
    resendEmail: async (req, res, next) => {
        const input = req.body;
        let query = 'UPDATE users SET resend_email=true WHERE username=$1'
        let params = [input.username];
        runQuery(req.db, query, params);
        console.log(input)

        res.json(input)

    }
}
const passwordEncrypt = async (password) => {
    const saltRounds = 10 //the higher the better - the longer it takes to generate & compare
    return bcrypt.hashSync(password, saltRounds)

}
const runQuery = async (db, query, params) => {
    return new Promise((resolve, reject) => {
        db.query(query, params, (err, result) => {
            if (err) {
                return reject(err);

            } else {
                return resolve(result);
            }

        })
    })

}
const validatePasswordStrength = async (password) => {
    return new Promise((resolve, reject) => {
        Object.keys(config.passwordConfig).forEach(element => {
            switch (element) {
                case 'passwordLength':

                    if (password.length < config.passwordConfig[element]) {

                        throw new Error("You should have a minimum password length of " + config.passwordConfig[element] + " characters.")
                    }
                    break;
                case 'passwordCapitalLetter':
                    if (password.replace(/[^A-Z]/g, "").length < config.passwordConfig[element]) {
                        throw new Error("You should have a minimum  of " + config.passwordConfig[element] + " characters in capital letter.")
                    }
                    break;
                case 'passwordSpecialCharacters':
                    if ((password.length - password.replace(/[^a-zA-Z0-9]/g, "").length) < config.passwordConfig[element]) {
                        throw new Error("You should have a minimum  of " + config.passwordConfig[element] + " special characters.")
                    }
                    break;
                default:
                    throw new Error("No matching config found");


            }

        });
        resolve(true)
    })
}
const ValidateEmail = (mail) => {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)) {
        return (true)
    }

    return (false)
}
const comparePassword = async (passwordA, passwordB) => {
    return new Promise((resolve, reject) => {
        bcrypt.compare(passwordA, passwordB, function (err, res) {
            if (err) {
                return reject(false);
            }

            resolve(res);


        })
    })
}
const updatePasswordQuery = async (db, username, password) => {
    return new Promise(async (resolve, reject) => {
        let query0 = "SELECT * FROM user_password WHERE username =$1 and( NOT is_deleted =true) ORDER BY created_on ASC offset 0 limit $2"
        let params0 = [username, config.max_password_store]
        let resp0 = await runQuery(db, query0, params0);
        if (resp0.rows.length > 0) {

            try {
                for (let row of resp0.rows) {
                    try {
                        let compPass = await comparePassword(password, row.password);

                        if (compPass) {
                            throw new Error("You cannot choose a password from last " + config.max_password_store + " used passwords.");
                        }

                    } catch (e) {

                        throw e;
                    }
                }
            } catch (e) {

                return reject(e);
            }

            if (resp0.rows.length == config.max_password_store) {
                let query1 = 'UPDATE user_password SET is_deleted=true WHERE username=$1 and id=$2'
                let params1 = [username, resp0.rows[0]['id']];
                runQuery(db, query1, params1);

            }

        }
        password = await passwordEncrypt(password)
        let query = 'UPDATE users SET password=$2,password_set_time=$3 WHERE username=$1'
        var d = new Date();

        let params = [username, password, d.getTime()];
        runQuery(db, query, params);
        let param2 = [username, password]
        let query2 = "INSERT INTO user_password(username,password) values($1,$2)"

        runQuery(db, query2, param2);
        resolve(true)


    })
}