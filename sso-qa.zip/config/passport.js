const bcrypt = require('bcrypt')
const winston = require('winston')
const LocalStrategy = require('passport-local').Strategy
const jwt = require('jsonwebtoken');
const redis = require('redis');
const config = require('./')
const client = redis.createClient(config.redisConf);
module.exports = (passport, db) => {
	passport.use(
		new LocalStrategy(
			async (username, password, cb) => {
				console.log("started Login process")
				try {
					let userObj
					userObj = await findUser(username)

					if (userObj) {
						if (userObj.is_locked) {
							throw new Error("Your account has ben locked.Please contact Administrator.");
						}
						if (!userObj.is_active) {
							throw new Error("Your account is inactive.Please contact Administrator.");
						}
						if (userObj.failure_attempts >= config.max_failure_attempts) {
							throw new Error("You have exceeded the maximum allowed attempts.");

						}
						console.log("comparing password")
						let passwordCompare = await comparePassword(password, userObj.password);
						if (!passwordCompare) {
							//password did not match
							let unsuccessfulAttempts = userObj.failure_attempts + 1
							let locked = false
							if (unsuccessfulAttempts == config.max_failure_attempts) {
								locked = true
							}
							updateFailureAttempts(username, unsuccessfulAttempts, locked)
							throw new Error("You have made " + unsuccessfulAttempts + " unsuccessful attempt(s). Maximum " + config.max_failure_attempts + " attempts are allowed for login.");
						} else {
							//password matched.
							const user = {
								id: userObj.id,
								username: userObj.username,
								type: userObj.type
							};
							var i = 'authentication.aperiohealth.com'; // Issuer 
							var s = userObj.username; // Subject 
							var a = '*.aperiohealth.com'; // Audience

							// SIGNING OPTIONS
							var signOptions = {
								issuer: i,
								subject: s,
								audience: a,
								//expiresIn: "12h",
								algorithm: "RS256"
							};
							console.log("signing token")
							const token = jwt.sign(user, config.token_secret, signOptions);

							const response = {
								username: user.username,
								token: token
							};
							//code to check password expiry
							var d = new Date();
							var n = d.getTime();

							if (parseFloat(userObj.password_set_time) + (parseFloat(config.password_expiry_days) * 24 * 60 * 60 * 1000) <= n) {
								response.passwordExpired = true
							}
							///
							console.log("Failure attempts updating")
							updateFailureAttempts(username, 0)
							client.set(token, JSON.stringify(response), redis.print);
							client.expire(token, config.token_expiry_seconds);
							return cb(null, response)
							//return res.json();
						}

					} else {
						throw new Error("username/password not correct.");
					}

				} catch (e) {
					console.log(cb)
					// return new Error(e);
					return cb(e);
				}

			}))

	passport.serializeUser((user, done) => {

		done(null, user.user.id)
	})

	passport.deserializeUser(
		async (id, cb) => {
			let query = 'SELECT  username FROM users WHERE username = $1 and failure_attempts<=$2'
			let params = [parseInt(id, 10), config.max_failure_attempts];
			let result = await runQuery(query, params);
			console.log(query)
			if (result) {
				cb(null, results.rows[0])
			}

		})

	function updateFailureAttempts(username, attempts, is_locked = false) {
		let query = 'UPDATE  users SET failure_attempts=$2,is_locked=$3 WHERE username=$1'
		let params = [username, attempts, is_locked];
		runQuery(query, params);
	}
	async function findUser(username) {
		console.log('finding user')
		let query = 'SELECT username, password,is_active,is_locked,failure_attempts,password_set_time FROM users WHERE username=$1'
		let params = [username];
		let result = await runQuery(query, params);
		console.log('result user found')
		if (result.rows.length > 0) {
			return result.rows[0];
		} else {
			throw new Error("username/password not correct.");
		}

	}
	async function runQuery(query, params) {
		return new Promise((resolve, reject) => {
			console.log('run query promise')
			db.query(query, params, (err, result) => {
				if (err) {
					console.log('encountered error')
					console.log(err)
					return reject(err);

				} else {
					console.log('result resolve')
					return resolve(result);
				}

			})
		})
	}
	async function comparePassword(passwordA, passwordB) {
		return new Promise((resolve, reject) => {
			bcrypt.compare(passwordA, passwordB, function (err, res) {
				if (err) {
					return reject(false);
				}

				resolve(res);


			})
		})
	}
}