module.exports = {
	db: {},
	redisConf: {},
	token_secret: ``,
	token_expiry_seconds: 0,
	session_secret: 'test',
	max_failure_attempts: 0,
	passwordConfig: {
		'passwordLength': 0,
		'passwordCapitalLetter': 0,
		'passwordSpecialCharacters': 0

	},
	max_password_store: 0,
	max_password_store: 0,
	password_expiry_days: 0
}