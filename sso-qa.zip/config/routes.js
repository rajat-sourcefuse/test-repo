const winston = require('winston')
const {
	requiresLogin,
	requiresAdmin
} = require('./middlewares/authorization')
const admin = require('../app/admin')
const users = require('../app/users')
const person = require('./person')
const monitoring = require('../app/monitoring')
var helmet = require('helmet')

module.exports = (app, passport, db) => {
	app.use(helmet())
	app.post('/api/login', passport.authenticate('local', {
		session: false
	}), users.login)
	app.get('/api/logout', users.logout)

	app.post('/api/userExists', function (req, res, next) {
		req.db = db;
		next()
	}, person.userExists)
	app.post('/api/register', function (req, res, next) {
		req.db = db;
		next()
	}, person.register)
	app.post('/api/lockAccount', function (req, res, next) {
		req.db = db;
		next()
	}, person.lockAccount)
	app.post('/api/unlockAccount', function (req, res, next) {
		req.db = db;
		next()
	}, person.unlockAccount)
	app.post('/api/activateAccount', function (req, res, next) {
		req.db = db;
		next()
	}, person.activateAccount)
	app.post('/api/deactivateAccount', function (req, res, next) {
		req.db = db;
		next()
	}, person.deactivateAccount)
	app.post('/api/changePassword', function (req, res, next) {
		req.db = db;
		next()
	}, person.changePassword)
	app.post('/api/resetPassword', function (req, res, next) {
		req.db = db;
		next()
	}, person.resetPassword)
	app.get('/api/ping', requiresLogin, users.ping)

	app.get('/health', monitoring.health(db))

	app.use(function (err, req, res, next) {
		if (err.message && (~err.message.indexOf('not found'))) {
			return next()
		}

		winston.error(err.stack)

		return res.status(401).json({
			error: err.message
		})
	})

	app.use(function (req, res) {
		const payload = {
			url: req.originalUrl,
			error: 'Not found'
		}
		if (req.accepts('json')) return res.status(404).json(payload)

		res.status(404).render('404', payload)
	})
}