
ALTER TABLE public.patient_address ALTER COLUMN versioned SET DEFAULT 0;
DELETE FROM oml_property WHERE object = 'patient' AND organization_id = '' AND property = 'MRN';
INSERT INTO oml_property(organization_id,object,property,display_name,data_type,search_config,data_attributes,dependency,is_calculated,calculation_formula,allow_multiple_values,default_value,display_when_referred,required,property_permissions,allow_edit,unique_index,comments,is_deleted) values ('','patient','mrn','MRN','string','','[]','[]',true,'{"phpFunction":"getAlphaNumeric","parameters":["id"]}',false,'',true,false,false,true,false,'',false);
UPDATE oml_property SET default_value = '0' WHERE object = 'patientAddress' AND organization_id = '' AND property = 'versioned';
UPDATE oml_property SET display_name = 'Blood sugar level ' WHERE object = 'patientVital' AND organization_id = '' AND property = 'a1c';
UPDATE patient_address SET versioned = 0 where  versioned IS NULL;
