
UPDATE organization_employee SET personal_email = 'admin@aperiohealth.com',work_email = 'admin@aperiohealth.com' WHERE id = 'organizationEmployee:001';