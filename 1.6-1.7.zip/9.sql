
UPDATE patient_allergy SET is_active = true;
