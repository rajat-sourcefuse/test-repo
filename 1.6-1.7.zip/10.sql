
UPDATE synap_user SET email = 'admin@aperiohealth.com',username = 'admin@aperiohealth.com' WHERE id = 'synapUser:001';