UPDATE synap_user SET email = 'admin@aperiohealth.com',username = 'admin@aperiohealth.com',failure_attempts = NULL,password_expiry_time = NULL,custom_property = NULL,checksum = NULL WHERE id = 'synapUser:001';
UPDATE patient SET is_image_upload='true' where image is not null or image !='';
UPDATE patient_medication SET medication_drug_route = meta_medication_delivery_route.value FROM  meta_medication_delivery_route WHERE patient_medication.meta_route = meta_medication_delivery_route.id;
